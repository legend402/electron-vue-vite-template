import { app, BrowserWindow, ipcMain } from 'electron'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'

globalThis.__filename = fileURLToPath(import.meta.url)
globalThis.__dirname = dirname(__filename)

const createWindow = () => {
  const win = new BrowserWindow({
    width: 800,
    height: 600,
    titleBarStyle: 'hidden',
    transparent: true,
    backgroundColor: '#00000000',
    frame: false,
    webPreferences: {
      nodeIntegration: true,
      preload: join(__dirname, '../preload/index.js'),
    },
  })

  initEvent(win)

  win.openDevTools()

  if (app.isPackaged) {
    win.loadFile(join(__dirname, '../preload/index.js'))
  } else {
    const url = `http://${process.env["VITE_DEV_SERVER_HOST"]}:${process.env["VITE_DEV_SERVER_PORT"]}`
    win.loadURL(url)
  }
}

app.whenReady().then(() => {
  createWindow()

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
  })
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})


function initEvent(app: BrowserWindow) {
  ipcMain.on('window-max', () => {
    if(app.isMaximized()) {
      app.restore()
    }else{
      app.maximize()
    }
  })
  ipcMain.on('window-min', function () {
    app.minimize();
  })
  ipcMain.on('window-close', function () {
    app.close();
  })
}