<script setup lang="ts">
import AppHeader from './components/AppHeader.vue';
</script>

<template>
  <AppHeader></AppHeader>
</template>

<style scoped>
</style>
