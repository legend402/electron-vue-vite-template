/// <reference types="vite/client" />

declare const versions: {
  node: () => string
  chrome: () => string
  electron: () => string
}